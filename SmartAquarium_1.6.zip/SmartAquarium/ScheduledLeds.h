#ifndef ScheduledLeds_H
#define ScheduledLeds_H

#include "Arduino.h"
#include "ScheduleTime.h"
#include "ScheduledLedPoint.h"

class ScheduledLeds {
	public:
		ScheduledLeds(int pin);
		void addSchedulePoint(ScheduledLedPoint *schedulePoint);
    void process(ScheduleTime currentTime);
    void freezeLedLevel(int targetLevel, int minutes);
		void unfreeze();
		int getLedLevel();
		String getFreezedStatus();
	private:
		int _pin;
    ScheduledLedPoint *_schedule[10];
		int _scheduleSize;
		int _count;
		int _size = 10;
    long _unfreezeTime;
    int _currentLevel;
		int _freezeLevel;
    ScheduleTime _lastTime;
    void setTransitionalLightLevel(ScheduleTime now, ScheduledLedPoint prevPoint, ScheduledLedPoint nextPoint);
    bool setLightLevel(int targetLevel);
};

#endif
