#include "Arduino.h"
#include "Relays.h"

Relays::Relays() {
	_count = 0;
	_size = 2;
	ScheduledRelay* _relays[_size];
}

// void Relays::begin() {
// 	Serial.println("Init relay(s)!");
// 	for (int i = 0; i < _count; i++) {
// 		ScheduledRelay* relay = _relays[i];
// 		initRelay(relay);
// 	}
// }

void Relays::addRelay(ScheduledRelay* relay) {
	Serial.print("Adding a relay");
	Serial.println(relay->toString());
	ensureCapacity();
	_relays[_count++] = relay;
	initRelay(relay);
}

void Relays::checkRelaysState(ScheduleTime currentTime) {
	// if (millis() % 1000 == 0) { //every second
		for (int i = 0; i < _count; i++) {
			ScheduledRelay* relay = _relays[i];
			relay->checkState(currentTime);
		}
	// }
}

void Relays::initRelay(ScheduledRelay* relay) {
	pinMode(relay->getPin(), OUTPUT);
	relay->switchOff();
	Serial.print("Relay inited: ");
	Serial.println(relay->toString());
}

void Relays::ensureCapacity() {
	if (_count >= _size) {
		Serial.println("Need to increase array");
		int newSize = 2*_size;
		ScheduledRelay *newArray[newSize];
		for (size_t i = 0; i < _count; i++) {
			newArray[i] = _relays[i];
		}
		delete[] _relays;
		*_relays = *newArray;
		_size = newSize;
	}
}

void Relays::switchForMinutes(int relayIndex, bool targetState, int min) {
	ScheduledRelay* relay = _relays[relayIndex];
	relay->switchForMinuntes(targetState, min);
}

void Relays::unfreezeNow(int relayIndex) {
	ScheduledRelay* relay = _relays[relayIndex];
	relay->unfreezeNow();
}
