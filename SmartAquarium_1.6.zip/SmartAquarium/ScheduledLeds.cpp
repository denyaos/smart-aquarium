#include "Arduino.h"
#include "ScheduledLeds.h"

ScheduledLeds::ScheduledLeds(int pin) {
  pinMode(pin, OUTPUT);
  _pin = pin;
  _scheduleSize = 0;
  _currentLevel = 0;
  _unfreezeTime = millis();
}

void ScheduledLeds::addSchedulePoint(ScheduledLedPoint *schedulePoint) {
  _schedule[_scheduleSize++] = schedulePoint;
}

void ScheduledLeds::process(ScheduleTime now) {

  if(!now.isPresent()) {
    if (millis() % 5000 == 0) {
      Serial.println("No current time provided for serving LED lights.");
    }
  } else if (millis() < _unfreezeTime) {
    setLightLevel(_freezeLevel);
    if (millis() % 5000 == 0) {
      Serial.print("LEDs' level freezed at ");
      Serial.print(_currentLevel/10);
      Serial.println("%");
    }
  } else {
    for (int i = 0; i < _scheduleSize; i++) {
      ScheduledLedPoint nextPoint = *_schedule[i];
      if (now.isBefore(nextPoint.getTime())) {
        if (i == 0) {
          setTransitionalLightLevel(now, *_schedule[_scheduleSize - 1], nextPoint);
        } else {
          setTransitionalLightLevel(now, *_schedule[i - 1], nextPoint);
        }
        return;
      }
    }

    if (_scheduleSize > 0) {
          setTransitionalLightLevel(now, *_schedule[_scheduleSize - 1], *_schedule[0]);
    } else {
      if (setLightLevel(800))
        Serial.println("Empty schedule, LED level is set to 80%.");
    }
  }
}

void ScheduledLeds::setTransitionalLightLevel(ScheduleTime now, ScheduledLedPoint prevPoint, ScheduledLedPoint nextPoint) {
  int wholePeriod = nextPoint.getTime().secondsAfter(prevPoint.getTime());
  int passedPeriod = now.secondsAfter(prevPoint.getTime());
  int precisionBooster = 1000;
  int boostedPercentage = precisionBooster * passedPeriod / wholePeriod;
  int targetLevel = prevPoint.getLevel() + (nextPoint.getLevel() - prevPoint.getLevel()) * boostedPercentage / precisionBooster;
  setLightLevel(targetLevel);
}

bool ScheduledLeds::setLightLevel(int targetLevel) { // 0..1000

  static int currentPWM = 0;

  if (targetLevel > _currentLevel) { // slow down change of lighting level
    targetLevel = _currentLevel + 1;
  }
  if (_currentLevel > targetLevel) { // slow down change of lighting level
    targetLevel = _currentLevel - 1;
  }

  int targetPWM = map(targetLevel, 0, 1000, 0, 1023);
  if (currentPWM != targetPWM) {
    analogWrite(_pin, targetPWM);
    currentPWM = targetPWM;
    // Serial.println(currentPWM);

    // if (abs(_currentLevel - targetLevel) >= 10) {
      _currentLevel = targetLevel;
      Serial.print("Setting LED lights level to ");
      Serial.print(getLedLevel());
      Serial.print("%.");
      Serial.print(" PWM value: ");
      Serial.print(currentPWM);
      Serial.println();
    // }

    return true;
  } else {
    return false;
  }
}

void ScheduledLeds::freezeLedLevel(int targetLevel, int minutes) {
  _unfreezeTime = millis() + minutes * 60 * 1000;
  _freezeLevel = targetLevel * 10;
}

void ScheduledLeds::unfreeze() {
  _unfreezeTime = millis();
}

int ScheduledLeds::getLedLevel() {
  int res = (_currentLevel / 10) + ((_currentLevel % 10 < 5) ? 0 : 1);
  return res;
}

String ScheduledLeds::getFreezedStatus() {
  String result = "";
  Serial.print("unfreeze: ");
  Serial.println(_unfreezeTime);
  Serial.print("miilis: ");
  Serial.println(millis());

  long diff = (_unfreezeTime - millis());
  diff = diff / 1000;

  if (diff > 1) {
    result = result + "Freezed for ";
    if (diff > 60) {
      int minutes = diff / 60;
      result = result + minutes + " min ";
    }
    int seconds = diff % 60;
    result = result + seconds + " sec.";
  }
  return result;
}
