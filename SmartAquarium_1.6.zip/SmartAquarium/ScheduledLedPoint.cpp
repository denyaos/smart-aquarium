#include "Arduino.h"
#include "ScheduledLedPoint.h"

ScheduledLedPoint::ScheduledLedPoint(ScheduleTime time, int level) {
  _time = time;
  _level = level * 10;
}

ScheduleTime ScheduledLedPoint::getTime() {
	return _time;
}

int ScheduledLedPoint::getLevel() {
  return _level;
}
