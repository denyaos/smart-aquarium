#ifndef ScheduledRelay_H
#define ScheduledRelay_H

#include "Arduino.h"
#include "ScheduleTime.h"

class ScheduledRelay {
	public:
    ScheduledRelay(
    						String name,
    						int pin,
    						int normalOnState,
    						ScheduleTime onTime,
    						ScheduleTime offTime);
		void checkState(ScheduleTime currentTime);
    void setSwitchOnTime(ScheduleTime time);
    void setSwitchOffTime(ScheduleTime time);
    void switchOn();
    void switchOff();
    bool relayIsOn();
    bool relayIsOff();
    int getPin();
		String toString();
		void switchForMinuntes(bool targetState, int min);
		void unfreezeNow();
	private:
    void log(String message);
    String _name;
  	int _pin;
		int _state;
  	int _normalOnState;
  	ScheduleTime _onTime;
  	ScheduleTime _offTime;
		unsigned long _unfreezeTime;
};

#endif
