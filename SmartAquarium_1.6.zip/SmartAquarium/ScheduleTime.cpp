#include "Arduino.h"
#include "ScheduleTime.h"

ScheduleTime::ScheduleTime(int hour) {
  _isPresent = true;
  _hour = hour;
  _min = 0;
  _sec = 0;
}

ScheduleTime::ScheduleTime(int hour, int min) {
  _isPresent = true;
  _hour = hour;
  _min = min;
  _sec = 0;
}

ScheduleTime::ScheduleTime(int hour, int min, int sec) {
  _isPresent = true;
  _hour = hour;
  _min = min;
  _sec = sec;
}

ScheduleTime::ScheduleTime() {
  _isPresent = false;
}

bool ScheduleTime::isPresent() {
  return _isPresent;
}

bool ScheduleTime::isBefore(ScheduleTime time) {
  return _hour < time._hour || (_hour == time._hour && _min < time._min);
}

bool ScheduleTime::isAfter(ScheduleTime time) {
  return _hour > time._hour || (_hour == time._hour && _min >= time._min);
}

int ScheduleTime::secondsAfter(ScheduleTime time) {
  return (_hour - time._hour) * 3600 + (_min - time._min) * 60 + _sec - time._sec;
}
