#include "Arduino.h"
#include "ScheduledRelay.h"

ScheduledRelay::ScheduledRelay(
						String name,
						int pin,
						int normalOnState,
						ScheduleTime onTime,
						ScheduleTime offTime) {
	_name = name;
	_pin = pin;
	_normalOnState = normalOnState;
	_onTime = onTime;
	_offTime = offTime;
	_state = normalOnState == HIGH ? LOW : HIGH;
	_unfreezeTime = millis();
}

void ScheduledRelay::checkState(ScheduleTime currentTime) {
	if (millis() < _unfreezeTime) {
		if (millis() % 10000 == 0) {
			log("shedule freezed");
		}
	} else if (!currentTime.isPresent()) {
		log("no time information given. Relay will be switched off.");
		switchOff();
	} else if (currentTime.isBefore(_onTime) && relayIsOn()) {
		log("too early to operate. Relay will be switched off.");
		switchOff();
	} else if (currentTime.isAfter(_onTime) && currentTime.isBefore(_offTime) && relayIsOff()) {
		log("time to operate. Relay will be switched on.");
		switchOn();
	} else if (currentTime.isAfter(_offTime) && relayIsOn()) {
		log("too late to operate. Relay will be switched off.");
		switchOff();
	} else {
		String s = _state == _normalOnState ? "ON" : "OFF";
		s = "no actions required. Relay is " + s;
		//log(s);
	}
}

void ScheduledRelay::setSwitchOnTime(ScheduleTime time) {
	_onTime = time;
}

void ScheduledRelay::setSwitchOffTime(ScheduleTime time) {
	_offTime = time;
}

void ScheduledRelay::switchOn() {
	_state = _normalOnState;
	digitalWrite(_pin, _state);
  log("switched ON.");
}

void ScheduledRelay::switchOff() {
	_state = _normalOnState == HIGH ? LOW : HIGH;
	digitalWrite(_pin, _state);
  log("switched OFF.");
}

bool ScheduledRelay::relayIsOn() {
	return _state == _normalOnState;
}

bool ScheduledRelay::relayIsOff() {
	return !relayIsOn();
}

int ScheduledRelay::getPin() {
	return _pin;
}

void ScheduledRelay::log(String message) {
	String messageHeader =  "Relay [" + _name + "]: ";
	String completeMessage = messageHeader + message;
	Serial.println(completeMessage);
}

String ScheduledRelay::toString() {
	return "Relay: [name: " + _name + ", state: " + _state + "]";
}

void ScheduledRelay::switchForMinuntes(bool targetState, int min) {
	if (targetState) {
		switchOn();
	} else {
		switchOff();
	}
	_unfreezeTime = millis() + min*60*1000;
}

void ScheduledRelay::unfreezeNow() {
	_unfreezeTime = millis();
}
