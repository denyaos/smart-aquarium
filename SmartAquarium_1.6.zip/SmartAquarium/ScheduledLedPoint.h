#ifndef ScheduledLedPoint_H
#define ScheduledLedPoint_H

#include "Arduino.h"
#include "ScheduleTime.h"

class ScheduledLedPoint {
  public:
    ScheduledLedPoint(ScheduleTime time, int level);
    ScheduleTime getTime();
    int getLevel();
	private:
		ScheduleTime  _time;
    int _level;
};

#endif
