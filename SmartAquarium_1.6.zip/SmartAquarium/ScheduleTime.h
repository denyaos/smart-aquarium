#ifndef ScheduleTime_H
#define ScheduleTime_H

#include "Arduino.h"

class ScheduleTime {
	public:
		ScheduleTime();
		ScheduleTime(int hour);
		ScheduleTime(int hour, int min);
		ScheduleTime(int hour, int min, int sec);
		bool isPresent();
		bool isBefore(ScheduleTime time);
		bool isAfter(ScheduleTime time);
		int secondsAfter(ScheduleTime time);
	private:
		bool _isPresent;
		int _hour;
		int _min;
		int _sec;
};

#endif
