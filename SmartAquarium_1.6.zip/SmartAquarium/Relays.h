#ifndef Relays_H
#define Relays_H

#include "Arduino.h"
#include "ScheduledRelay.h"
#include "ScheduleTime.h"

class Relays {
	public:
		Relays();
  	// void begin();
		void addRelay(ScheduledRelay *relay);
		void checkRelaysState(ScheduleTime currentTime);
		void switchForMinutes(int relayIndex, bool targetState, int min);
		void unfreezeNow(int relayIndex);
	private:
		void initRelay(ScheduledRelay *relay);
		void ensureCapacity();
		int _count;
		int _size;
		ScheduledRelay *_relays[];
};

#endif
